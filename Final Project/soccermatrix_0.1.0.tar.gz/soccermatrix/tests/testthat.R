library(testthat)
library(soccermatrix)

test_check("soccermatrix")
